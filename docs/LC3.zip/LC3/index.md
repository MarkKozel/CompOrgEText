---
title: LC3 Assembly Emulator
shorttitle: The Little Computer 3

tags: []
---
# {{ $frontmatter.title }}
**{{ $frontmatter.shorttitle }}**




    