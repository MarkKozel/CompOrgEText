# Contributors

### Thank you to the following for helping make this material better:

## Editors
The following editors provided peer-review comments during the creation of this text:
### Rachel Baumann
Tech Writer and Project Lead in the public sector

### Michael Wagner
Instructor, Hancock College Math Sciences Department, Computer Science

## Student Contributors:
The following Classes/Students provided comments that fixed errors and made the text more understandable

**CS-131 Fall 2022**: Aidan Soares, Ryan Kozel, Mikayla Lopez, Paul Motter, Elijah Villanueva

**CS-131 Fall 2023**: Kathryn Cardona, Dylan Martin
