# VuePress Test Resources

Demos and examples of using built-in and custom VuePress elements in markdown pages

[Examples](./Examples)

[Layouts](./Layouts)

[Templates](./Templates)