for(int i = 0; i < 10; i++){
  myArray[i] *= 2;
  myArray[i] += 1;
}
System.out.println("All values updated");