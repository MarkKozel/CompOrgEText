# Course Information

**Allan Hancock College - Santa Maria, CA**

**Computer Science | Mathematical Sciences Department**

## Course Information

**Introduction to Computer Architecture and Assembly Language Programming** - Data representation and conversion, assembly language programming, digital design, and basic processor architecture.

* **Units**: 3.0
* **Prerequisite**: CS 111 - Fundamentals of Programming 1
* **Acceptable for Credit**: Transfer to UC, CSU
* **C-ID Course Number**: COMP 142
* **Course Offered**: Fall, Spring
* **Grading Method**: Letter Grade Only
