# Links

## Conversions

[Rapid Tables Binary to Hex](https://www.rapidtables.com/convert/number/binary-to-hex.html)

[Rapid Tables Binary](https://www.rapidtables.com/convert/number/binary-converter.html)

## Number Systems

[Fixed-Point Arithmetic](https://en.wikipedia.org/wiki/Fixed-point_arithmetic)

[IEEE 754 Standard for Floating Point Arithmetic](https://en.wikipedia.org/wiki/IEEE_754)

[Java Primitive Data Types](https://docstore.mik.ua/orelly/java-ent/jnut/ch02_04.htm)

[Computer Number Formats](https://en.wikipedia.org/wiki/Computer_number_format)