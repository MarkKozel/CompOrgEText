|A|B|C<sub>in</sub>|Sum|C<sub>out</sub>|
|-|-|-|-|-|
|0|0|0|0|0|
|0|0|1|1|0|
|0|1|0|1|0|
|0|1|1|0|1|
|1|0|0|1|0|
|1|0|1|0|1|
|1|1|0|0|1|
|1|1|1|1|1|

There are four (4) different possible combinations of bits added together:
1. All three (3) input bits are zero (0) - Resulting in *Sum* 0 and *C<sub>out</sub>* 0
1. Only one (1) input bit is one (1) - Resulting in *Sum* 1 and *C<sub>out</sub>* 0
1. Two (2) input bits are one (1) - Resulting in *Sum* 0 and *C<sub>out</sub>* 1
1. All three (3) bits are one (1) - Resulting in *Sum* 1 and *C<sub>out</sub>* 1