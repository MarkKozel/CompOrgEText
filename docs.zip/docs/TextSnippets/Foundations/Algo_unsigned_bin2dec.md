Recall that array indexes start at zero(0). Number positions in a number string also start at zero. So the value in the 1st position is said to be in *position 0*

1. Multiply a Binary value by 2 raised to the power if the value's position
1. Add the result to the final Decimal result
1. Repeat for all Binary values