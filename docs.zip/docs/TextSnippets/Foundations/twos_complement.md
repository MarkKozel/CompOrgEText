1. Flip all the bits
1. Add 1 to the resulting bits

| Step | bit value | decimal value |
|-|-|-|
|Starting Value| 0101 | 5 |
|Flip the Bits|1010| n/a |
|Add 1|1011| -5|

**note:** the decimal value after flipping the bits does not matter