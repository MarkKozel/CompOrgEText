int x = 0;
for(int i = 0; i < 10; i++) {
  x += i; //Add current value if i to x
}