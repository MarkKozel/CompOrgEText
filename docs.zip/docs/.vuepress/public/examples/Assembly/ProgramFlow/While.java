//Condition: Keep looping until i is 10 or more
//Action: Starting at 0, add 2 to i each loop

int i = 0; //data to update in the loop
while(i <= 10){
  i += 2; //Add 2 to the data
}